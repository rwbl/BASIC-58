package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static b4j.example.b58serial _ser = null;
public static anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static b4j.example.b58protocol _b58protocol = null;
public static b4j.example.utils _utils = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 14;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 15;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 16;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 18;BA.debugLine="Ser.Initialize(Me, \"Ser\")";
_ser._initialize /*String*/ (ba,main.getObject(),"Ser");
 //BA.debugLineNum = 19;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 23;BA.debugLine="Ser.ExecuteCommand(\"@SER LISTPORTS\")";
_ser._executecommand /*String*/ ("@SER LISTPORTS");
 //BA.debugLineNum = 24;BA.debugLine="Ser.ExecuteCommand(\"@SER CONNECT COM10\")";
_ser._executecommand /*String*/ ("@SER CONNECT COM10");
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
b58protocol._process_globals();
utils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private Ser As B58Serial";
_ser = new b4j.example.b58serial();
 //BA.debugLineNum = 10;BA.debugLine="Private bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 11;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public static String  _ser_connected() throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Private Sub Ser_Connected";
 //BA.debugLineNum = 29;BA.debugLine="Log($\"[Main.Ser_Connected] OK\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("4196609",("[Main.Ser_Connected] OK"),0);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public static String  _ser_datareceived(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Private Sub Ser_DataReceived(buffer() As Byte)";
 //BA.debugLineNum = 37;BA.debugLine="Log($\"[Main.Ser_DataReceived] ${bc.HexFromBytes(b";
anywheresoftware.b4a.keywords.Common.LogImpl("4327681",("[Main.Ser_DataReceived] "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_bc.HexFromBytes(_buffer)))+""),0);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public static String  _ser_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Private Sub Ser_NewData(buffer() As Byte)";
 //BA.debugLineNum = 33;BA.debugLine="Log($\"[Main.Ser_Newdata] ${bc.HexFromBytes(buffer";
anywheresoftware.b4a.keywords.Common.LogImpl("4262145",("[Main.Ser_Newdata] "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_bc.HexFromBytes(_buffer)))+""),0);
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public static String  _ser_portsfound(anywheresoftware.b4a.objects.collections.List _ports) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Private Sub Ser_PortsFound(ports As List)";
 //BA.debugLineNum = 41;BA.debugLine="Log($\"[Main.Ser_PortsFound] ${ports}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("4393217",("[Main.Ser_PortsFound] "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_ports.getObject()))+""),0);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
}
