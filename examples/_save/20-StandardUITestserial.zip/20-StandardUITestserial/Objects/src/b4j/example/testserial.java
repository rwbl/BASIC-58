package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class testserial extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.testserial", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.testserial.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.serial.Serial _serialline = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astreams = null;
public anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
public boolean _misconnected = false;
public Object _mcallback = null;
public String _meventname = "";
public b4j.example.main _main = null;
public String  _astreams_error() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Private Sub AStreams_Error";
 //BA.debugLineNum = 60;BA.debugLine="If SubExists(mCallback, mEventName & \"_Error\") Th";
if (__c.SubExists(ba,_mcallback,_meventname+"_Error")) { 
 //BA.debugLineNum = 61;BA.debugLine="CallSub(mCallback, mEventName & \"_Error\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Error");
 };
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Private Sub AStreams_NewData(Buffer() As Byte)";
 //BA.debugLineNum = 54;BA.debugLine="If SubExists(mCallback, mEventName & \"_NewData\")";
if (__c.SubExists(ba,_mcallback,_meventname+"_NewData")) { 
 //BA.debugLineNum = 55;BA.debugLine="CallSub2(mCallback, mEventName & \"_NewData\", Buf";
__c.CallSubNew2(ba,_mcallback,_meventname+"_NewData",(Object)(_buffer));
 };
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Private Sub AStreams_Terminated";
 //BA.debugLineNum = 66;BA.debugLine="If SubExists(mCallback, mEventName & \"_Terminated";
if (__c.SubExists(ba,_mcallback,_meventname+"_Terminated")) { 
 //BA.debugLineNum = 67;BA.debugLine="CallSub(mCallback, mEventName & \"_Terminated\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Terminated");
 };
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private SerialLine As Serial";
_serialline = new anywheresoftware.b4j.serial.Serial();
 //BA.debugLineNum = 4;BA.debugLine="Private AStreams As AsyncStreams";
_astreams = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 5;BA.debugLine="Private bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 6;BA.debugLine="Private mIsConnected As Boolean = False";
_misconnected = __c.False;
 //BA.debugLineNum = 8;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 9;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _connect(String _port) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Connect(Port As String)";
 //BA.debugLineNum = 19;BA.debugLine="Log($\"[TestSerial.Connect] Port: ${Port}\"$)";
__c.LogImpl("1458753",("[TestSerial.Connect] Port: "+__c.SmartStringFormatter("",(Object)(_port))+""),0);
 //BA.debugLineNum = 21;BA.debugLine="Disconnect";
_disconnect();
 //BA.debugLineNum = 23;BA.debugLine="Try";
try { //BA.debugLineNum = 24;BA.debugLine="SerialLine.Open(Port)";
_serialline.Open(_port);
 //BA.debugLineNum = 25;BA.debugLine="SerialLine.SetParams(115200, 8, 1, 0)";
_serialline.SetParams((int) (115200),(int) (8),(int) (1),(int) (0));
 //BA.debugLineNum = 27;BA.debugLine="AStreams.Initialize(SerialLine.GetInputStream, S";
_astreams.Initialize(ba,_serialline.GetInputStream(),_serialline.GetOutputStream(),"AStreams");
 //BA.debugLineNum = 29;BA.debugLine="mIsConnected = True";
_misconnected = __c.True;
 //BA.debugLineNum = 30;BA.debugLine="Log($\"[TestSerial.Connect] Connected: ${Port}\"$)";
__c.LogImpl("1458764",("[TestSerial.Connect] Connected: "+__c.SmartStringFormatter("",(Object)(_port))+""),0);
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 33;BA.debugLine="Log($\"[TestSerial.Connect][E] ${LastException.Me";
__c.LogImpl("1458767",("[TestSerial.Connect][E] "+__c.SmartStringFormatter("",(Object)(__c.LastException(ba).getMessage()))+""),0);
 };
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _disconnect() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Public Sub Disconnect";
 //BA.debugLineNum = 38;BA.debugLine="Try";
try { //BA.debugLineNum = 39;BA.debugLine="If AStreams.IsInitialized Then AStreams.Close";
if (_astreams.IsInitialized()) { 
_astreams.Close();};
 } 
       catch (Exception e4) {
			ba.setLastException(e4); //BA.debugLineNum = 41;BA.debugLine="Log(\"[TestSerial.Disconnect][E] Error closing st";
__c.LogImpl("1524292","[TestSerial.Disconnect][E] Error closing streams.",0);
 };
 //BA.debugLineNum = 44;BA.debugLine="Try";
try { //BA.debugLineNum = 45;BA.debugLine="If mIsConnected Then SerialLine.Close";
if (_misconnected) { 
_serialline.Close();};
 } 
       catch (Exception e9) {
			ba.setLastException(e9); //BA.debugLineNum = 47;BA.debugLine="Log(\"[TestSerial.Disconnect][E] Error closing po";
__c.LogImpl("1524298","[TestSerial.Disconnect][E] Error closing port.",0);
 };
 //BA.debugLineNum = 50;BA.debugLine="mIsConnected = False";
_misconnected = __c.False;
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Initialize(Callback As Object, EventNam";
 //BA.debugLineNum = 13;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 14;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 15;BA.debugLine="SerialLine.Initialize(\"SerialLine\")";
_serialline.Initialize("SerialLine");
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
