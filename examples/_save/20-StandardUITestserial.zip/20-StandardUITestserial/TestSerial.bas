﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.7
@EndOfDesignText@

Sub Class_Globals
	Private SerialLine As Serial
	Private AStreams As AsyncStreams
	Private bc As ByteConverter
	Private mIsConnected As Boolean = False

	Private mCallback As Object
	Private mEventName As String
End Sub

Public Sub Initialize(Callback As Object, EventName As String)
    mCallback = Callback
    mEventName = EventName
    SerialLine.Initialize("SerialLine")
End Sub

Public Sub Connect(Port As String)
	Log($"[TestSerial.Connect] Port: ${Port}"$)

	Disconnect

	Try
		SerialLine.Open(Port)
		SerialLine.SetParams(115200, 8, 1, 0)

		AStreams.Initialize(SerialLine.GetInputStream, SerialLine.GetOutputStream, "AStreams")

		mIsConnected = True
		Log($"[TestSerial.Connect] Connected: ${Port}"$)

	Catch
		Log($"[TestSerial.Connect][E] ${LastException.Message}"$)
	End Try
End Sub

Public Sub Disconnect
	Try
		If AStreams.IsInitialized Then AStreams.Close
	Catch
		Log("[TestSerial.Disconnect][E] Error closing streams.")
	End Try

	Try
		If mIsConnected Then SerialLine.Close
	Catch
		Log("[TestSerial.Disconnect][E] Error closing port.")
	End Try

	mIsConnected = False
End Sub

Private Sub AStreams_NewData(Buffer() As Byte)
	If SubExists(mCallback, mEventName & "_NewData") Then
		CallSub2(mCallback, mEventName & "_NewData", Buffer)
	End If
End Sub

Private Sub AStreams_Error
	If SubExists(mCallback, mEventName & "_Error") Then
		CallSub(mCallback, mEventName & "_Error")
	End If
End Sub

Private Sub AStreams_Terminated
	If SubExists(mCallback, mEventName & "_Terminated") Then
		CallSub(mCallback, mEventName & "_Terminated")
	End If
End Sub
