﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

#Macro: Title, Export B4XPages, ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	' Retro BASIC – A tiny BASIC interpreter inspired by Commodore 64 / MEGA65 BASIC.
	Private VERSION As String = "Retro BASIC v20261113 Alpha"

	Private fx As JFX
	Private xui As XUI

	Private Root As B4XView
	Private btnExecute As B4XView
	Private lblStatus As B4XView
	Private txtCommand As B4XView
	Private txtScreen As B4XView

	Private ProgramDir As String
	Private ProgramLines As Map
	
	Private Variables As Map

	'Program execution state
	Private RunLines As List
	Private RunPosition As Int

	'INPUT handling
	Private WaitingForInput As Boolean
	Private InputVariable As String

	'Arithmetic expression parser
	Private ExprText As String
	Private ExprPos As Int
	Private ExprError As Boolean

	'FOR / NEXT handling
	Private ForStack As List

	'GOSUB / RETURN handling
	Private GosubStack As List
End Sub

Public Sub Initialize
'	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")
	
	ProgramLines.Initialize
	RunLines.Initialize
	Variables.Initialize
	
	'Create RetroBasic data directory.
	ProgramDir = File.DirApp
	' File.Combine(File.DirApp, "RetroBasic")
	' File.MakeDir(File.DirUserHome, "RetroBasic")
	
	' UI
	B4XPages.SetTitle(Me, VERSION)
	B4XPages.GetNativeParent(Me).Resizable = False

	lblStatus.Text = "READY"

	InitializeUIStyleAmber
	
	InitializeScreen
End Sub


Private Sub InitializeUIStyleAmber	'ignore
	'--------------------------------------------------
	' Main application
	'--------------------------------------------------
	CSSUtils.SetBackgroundColor(Root, fx.Colors.From32Bit(0xFFDCD6C8))
	Root.SetColorAndBorder(xui.Color_ARGB(0xFFDCD6C8), 2, fx.Colors.From32Bit(0xFF4A4845), 0)

	'--------------------------------------------------
	' Terminal screen - VT220 Amber
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtScreen, "-fx-control-inner-background", "#191713")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-text-fill", "#FFBF69")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-fill", "#80613A")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-text-fill", "#FFFFFF")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-color", "#80613A")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-width", "2")

	txtScreen.Font = fx.CreateFont("Consolas", 16, False, False)

	'--------------------------------------------------
	' Command input
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtCommand, "-fx-background-color", "#211B13")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-text-fill", "#FFBF69")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-prompt-text-fill", "#C9954A")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-border-color", "#80613A")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-border-width", "1")

	txtCommand.Font = fx.CreateFont("Consolas", 17, False, False)

	'--------------------------------------------------
	' Execute button
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(btnExecute, "-fx-background-color", "#58544E")	'"#E0E2DC")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-text-fill", "#F2EFE9")			' "#303830")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-border-color", "#8B9489")

	'--------------------------------------------------
	' Status
	'--------------------------------------------------
	lblStatus.Font = fx.CreateFont("Consolas", 12, False, False)
	' CSSUtils.SetStyleProperty(lblStatus, "-fx-text-fill", "#465448")
	CSSUtils.SetStyleProperty(lblStatus, "-fx-text-fill", "#4A4845")

End Sub

Private Sub InitializeUIStyleGreen	'ignore
	'--------------------------------------------------
	' Main application
	'--------------------------------------------------
	CSSUtils.SetBackgroundColor(Root, fx.Colors.From32Bit(0xFFC8CBC5))

	'--------------------------------------------------
	' Terminal screen
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtScreen, "-fx-control-inner-background", "#17201B")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-text-fill", "#B7D6A5")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-fill", "#526452")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-text-fill", "#FFFFFF")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-color", "#667765")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-width", "2")

	txtScreen.Font = fx.CreateFont("Consolas", 16, False, False)

	'--------------------------------------------------
	' Command input
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtCommand, "-fx-background-color", "#202B23")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-text-fill", "#B7D6A5")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-prompt-text-fill", "#84977E")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-border-color", "#667765")

	txtCommand.Font = fx.CreateFont("Consolas", 17, False, False)

	'--------------------------------------------------
	' Execute button
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(btnExecute, "-fx-background-color", "#E0E2DC")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-text-fill", "#303830")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-border-color", "#8B9489")

	'--------------------------------------------------
	' Status
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(lblStatus, "-fx-text-fill", "#465448")
	lblStatus.Font = fx.CreateFont("Consolas", 12, False, False)
End Sub

Private Sub InitializeScreen

	PrintText("**** RETRO BASIC ****")
	PrintText("")
	PrintText("B4J BASIC INTERPRETER")
	PrintText("")
	PrintText("TYPE HELP FOR COMMANDS")
	PrintText("")
	PrintText("READY.")

	lblStatus.Text = "READY."
End Sub

Private Sub btnExecute_Click
    ProcessInput
End Sub

Private Sub txtCommand_Action
    ProcessInput
End Sub

Private Sub ProcessInput
	Dim Command As String = txtCommand.Text.Trim

	If Command = "" Then Return

	Log("INPUT: " & Command)

	txtCommand.Text = ""

	'If the BASIC program is waiting for INPUT,
	'treat the entered text as the variable value.
	If WaitingForInput Then
		Log("INPUT VALUE: " & Command)
		Log("INPUT VARIABLE: " & InputVariable)

		If InputVariable.EndsWith("$") = False And IsNumber(Command) = False Then
			PrintText("?REDO FROM START")
			PrintText("?")
			txtCommand.RequestFocus
			Return
		End If

		Variables.Put(InputVariable, Command)

		WaitingForInput = False

		ContinueProgram

		txtCommand.RequestFocus
		Return
	End If
	
	ExecuteCommand(Command)

	txtCommand.RequestFocus
End Sub

Private Sub ExecuteCommand(Command As String)
	Command = Command.Trim

	If Command = "" Then Return

	Dim UpperCommand As String = Command.ToUpperCase

	'Check whether this is a numbered BASIC program line.
	Dim SpacePos As Int = Command.IndexOf(" ")

	If SpacePos > 0 Then
		Dim FirstToken As String = Command.SubString2(0, SpacePos)

		If IsNumber(FirstToken) Then
			Dim LineNumber As Int = FirstToken
			Dim LineCode As String = Command.SubString(SpacePos + 1).Trim

			If LineCode = "" Then
				ProgramLines.Remove(LineNumber)
			Else
				ProgramLines.Put(LineNumber, LineCode)
				PrintText("STORED: " & LineNumber & " = " & LineCode)
			End If

			Return
		End If
	End If

	' Load and Save
	If UpperCommand = "SAVE" Or UpperCommand.StartsWith("SAVE ") Then
		SaveProgram(Command.SubString(4).Trim)
		Return
	End If

	If UpperCommand = "LOAD" Or UpperCommand.StartsWith("LOAD ") Then
		LoadProgram(Command.SubString(4).Trim)
		Return
	End If

	' Other commands
	Select Case UpperCommand
		Case "CLS"
			txtScreen.Text = ""

		Case "HELP"
			PrintText("AVAILABLE COMMANDS:")
			PrintText("PRINT <TEXT>")
			PrintText("LIST")
			PrintText("RUN")
			PrintText("CLS")
			PrintText("HELP")

		Case "LIST"
			ListProgram

		Case "RUN"
			RunProgram

		Case "NEW"
			ProgramLines.Clear
			Variables.Clear
			WaitingForInput = False
			PrintText("NEW PROGRAM")
			
		Case Else
			If UpperCommand.StartsWith("PRINT ") Then
				PrintBasicText(Command)
			Else
				PrintText("?SYNTAX ERROR")
			End If
	End Select

	lblStatus.Text = "READY."
End Sub

Private Sub ExecuteLet(LineCode As String) As Boolean
	Dim EqualPos As Int = LineCode.IndexOf("=")

	If EqualPos < 0 Then Return False

	Dim VariableName As String = LineCode.SubString2(4, EqualPos).Trim.ToUpperCase
	Dim Expression As String = LineCode.SubString(EqualPos + 1).Trim

	If VariableName = "" Or Expression = "" Then Return False

	If VariableName.Length > 2 Then Return False

	Dim FirstChar As String = VariableName.SubString2(0, 1)

	If FirstChar.CompareTo("A") < 0 Or FirstChar.CompareTo("Z") > 0 Then Return False
	
	If VariableName.Length = 2 And VariableName.EndsWith("$") = False Then Return False

	Dim QUOTES As String = Chr(34)

	'String variable.
	If VariableName.EndsWith("$") Then

		If Expression.StartsWith(QUOTES) And Expression.EndsWith(QUOTES) And Expression.Length >= 2 Then
			Expression = Expression.SubString2(1, Expression.Length - 1)

		Else
			Dim SourceVariable As String = Expression.ToUpperCase

			If SourceVariable.EndsWith("$") = False Then Return False
			If Variables.ContainsKey(SourceVariable) = False Then Return False

			Expression = Variables.Get(SourceVariable)
		End If

		Variables.Put(VariableName, Expression)
		Return True
	End If

	'Numeric expression.
	Dim Result As Double = 0

	Log("LET: Variable=" & VariableName & ", Expression=" & Expression)
	
	Result = EvaluateNumericExpression(Expression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Variables.Put(VariableName, NumberFormat(Result, 1, 6))
	
	Return True
End Sub

Private Sub RunProgram
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	Variables.Clear
	WaitingForInput = False

	PrintText("")
	PrintText("RUNNING...")
	PrintText("")

	'Get program line numbers in numerical order.
	RunLines.Initialize

	For Each Key As Object In ProgramLines.Keys
		RunLines.Add(Key)
	Next

	RunLines.Sort(True)

	RunPosition = 0

	If ForStack.IsInitialized = False Then
		ForStack.Initialize
	Else
		ForStack.Clear
	End If
	
	If GosubStack.IsInitialized = False Then
		GosubStack.Initialize
	Else
		GosubStack.Clear
	End If
	
	ContinueProgram
End Sub

Private Sub ContinueProgram
	Do While RunPosition < RunLines.Size

		Dim LineNumber As Int = RunLines.Get(RunPosition)
		RunPosition = RunPosition + 1

		Dim LineCode As String = ProgramLines.Get(LineNumber)
		Dim UpperLine As String = LineCode.ToUpperCase.Trim

		Select Case True

			Case UpperLine = "END"
				RunPosition = RunLines.Size

			Case UpperLine.StartsWith("GOSUB ")

				Dim TargetText As String = LineCode.SubString(6).Trim

				If IsNumber(TargetText) = False Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

				Dim TargetLine As Int = TargetText

				'Remember the position of the next BASIC line.
				GosubStack.Add(RunPosition)

				If JumpToLine(TargetLine) = False Then
					GosubStack.RemoveAt(GosubStack.Size - 1)
					Exit
				End If

			Case UpperLine.StartsWith("GOTO ")
				Dim TargetText As String = LineCode.SubString(5).Trim

				If IsNumber(TargetText) = False Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

				If JumpToLine(TargetText) = False Then Exit

			Case UpperLine.StartsWith("IF ")
				Dim ThenPos As Int = UpperLine.IndexOf("THEN")

				If ThenPos < 0 Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

				Dim Condition As String = LineCode.SubString2(3, ThenPos).Trim
				Dim TargetText As String = LineCode.SubString(ThenPos + 4).Trim

				If IsNumber(TargetText) = False Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

				If EvaluateCondition(Condition) Then
					If JumpToLine(TargetText) = False Then Exit
				End If

			Case UpperLine.StartsWith("PRINT ")
				PrintBasicText(LineCode)

			Case UpperLine.StartsWith("INPUT ")
				InputVariable = LineCode.SubString(6).Trim.ToUpperCase

				PrintText("?")
				WaitingForInput = True
				Return

			Case UpperLine.StartsWith("LET ")
				If ExecuteLet(LineCode) = False Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

			Case UpperLine.StartsWith("FOR ")

				If ExecuteFor(LineCode, RunPosition) = False Then
					PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
					Exit
				End If

			Case UpperLine = "NEXT" Or UpperLine.StartsWith("NEXT ")

				If ExecuteNext(LineCode) = False Then
					PrintText("?NEXT WITHOUT FOR IN LINE " & LineNumber)
					Exit
				End If

			Case UpperLine = "RETURN"

				If GosubStack.Size = 0 Then
					PrintText("?RETURN WITHOUT GOSUB IN LINE " & LineNumber)
					Exit
				End If

				RunPosition = GosubStack.Get(GosubStack.Size - 1)
				GosubStack.RemoveAt(GosubStack.Size - 1)
				
			Case Else
				PrintText("?SYNTAX ERROR IN LINE " & LineNumber)
				Exit

		End Select

	Loop

	WaitingForInput = False
	PrintText("")
	PrintText("READY.")
End Sub

Private Sub PrintBasicText(LineCode As String)
    Dim Value As String = LineCode.SubString(6).Trim
    Dim QUOTES As String = Chr(34)

    'Quoted text.
    If Value.StartsWith(QUOTES) And Value.EndsWith(QUOTES) And Value.Length >= 2 Then
        Value = Value.SubString2(1, Value.Length - 1)
        PrintText(Value)
        Return
    End If

    'Variable.
    Dim VariableName As String = Value.ToUpperCase

    If Variables.ContainsKey(VariableName) Then
        PrintText(Variables.Get(VariableName))
    Else
        PrintText("?UNDEFINED VARIABLE")
    End If
End Sub

Private Sub PrintText(Value As String)
    txtScreen.Text = txtScreen.Text & Value & CRLF
End Sub

Private Sub ListProgram
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	'Copy Map keys into a List.
	Dim LineNumbers As List
	LineNumbers.Initialize

	For Each Key As Object In ProgramLines.Keys
		LineNumbers.Add(Key)
	Next

	'Sort line numbers numerically.
	LineNumbers.Sort(True)

	'Display the BASIC program.
	For Each LineNumber As Int In LineNumbers
		Dim LineCode As String = ProgramLines.Get(LineNumber)
		PrintText(LineNumber & " " & LineCode)
	Next
End Sub

Private Sub SaveProgram(FileName As String)
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	If FileName = "" Then FileName = "PROGRAM.BAS"

	If FileName.Contains("/") Or FileName.Contains("\") Then
		PrintText("?INVALID FILE NAME")
		Return
	End If

	If FileName.Contains(".") = False Then
		FileName = FileName & ".bas"
	End If

	Try
		Dim LineNumbers As List
		LineNumbers.Initialize

		For Each Key As Object In ProgramLines.Keys
			LineNumbers.Add(Key)
		Next

		LineNumbers.Sort(True)

		Dim SavedLines As List
		SavedLines.Initialize

		For Each LineNumber As Int In LineNumbers
			Dim LineCode As String = ProgramLines.Get(LineNumber)
			SavedLines.Add(LineNumber & " " & LineCode)
		Next

		File.WriteList(ProgramDir, FileName, SavedLines)

		PrintText("SAVED: " & FileName)

	Catch
		PrintText("?SAVE ERROR")
		Log(LastException)
	End Try
End Sub

Private Sub LoadProgram(FileName As String)
	If FileName = "" Then FileName = "PROGRAM.BAS"

	If FileName.Contains("/") Or FileName.Contains("\") Then
		PrintText("?INVALID FILE NAME")
		Return
	End If

	If FileName.Contains(".") = False Then
		FileName = FileName & ".bas"
	End If

	If File.Exists(ProgramDir, FileName) = False Then
		PrintText("?FILE NOT FOUND: " & FileName)
		Return
	End If

	Try
		Dim SavedLines As List = File.ReadList(ProgramDir, FileName)

		'Clear the current program.
		ProgramLines.Clear

		'Restore the saved BASIC program.
		For Each SavedLine As String In SavedLines
			Dim SpacePos As Int = SavedLine.IndexOf(" ")

			If SpacePos > 0 Then
				Dim NumberText As String = SavedLine.SubString2(0, SpacePos)

				If IsNumber(NumberText) Then
					Dim LineNumber As Int = NumberText
					Dim LineCode As String = SavedLine.SubString(SpacePos + 1).Trim

					If LineCode <> "" Then
						ProgramLines.Put(LineNumber, LineCode)
					End If
				End If
			End If
		Next

		PrintText("LOADED: " & FileName)
		PrintText("LINES: " & ProgramLines.Size)

	Catch
		PrintText("?LOAD ERROR")
		Log(LastException)
	End Try
End Sub

Private Sub JumpToLine(TargetLine As Int) As Boolean
	For i = 0 To RunLines.Size - 1
		Dim LineNumber As Int = RunLines.Get(i)

		If LineNumber = TargetLine Then
			RunPosition = i
			Return True
		End If
	Next

	PrintText("?UNDEFINED LINE " & TargetLine)
	Return False
End Sub

Private Sub EvaluateCondition(Condition As String) As Boolean
	Dim Operators As List = Array As String("<=", ">=", "<>", "=", "<", ">")

	Dim OperatorFound As String = ""
	Dim OperatorPos As Int = -1

	'Find the comparison operator.
	For Each Op As String In Operators
		OperatorPos = Condition.IndexOf(Op)

		If OperatorPos >= 0 Then
			OperatorFound = Op
			Exit
		End If
	Next

	If OperatorPos < 0 Then
		PrintText("?INVALID CONDITION")
		Return False
	End If

	Dim LeftExpression As String = Condition.SubString2(0, OperatorPos).Trim
	Dim RightExpression As String = Condition.SubString(OperatorPos + OperatorFound.Length).Trim

	'String comparison.
	If IsStringExpression(LeftExpression) Or IsStringExpression(RightExpression) Then

		Dim LeftValue As String = GetBasicValue(LeftExpression)
		Dim RightValue As String = GetBasicValue(RightExpression)

		Select Case OperatorFound
			Case "="
				Return LeftValue = RightValue
			Case "<>"
				Return LeftValue <> RightValue
			Case Else
				PrintText("?INVALID STRING COMPARISON")
				Return False
		End Select
	End If

	'Numeric comparison.
	Dim A As Double = EvaluateNumericExpression(LeftExpression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Dim B As Double = EvaluateNumericExpression(RightExpression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Select Case OperatorFound
		Case "="
			Return A = B
		Case "<>"
			Return A <> B
		Case "<"
			Return A < B
		Case ">"
			Return A > B
		Case "<="
			Return A <= B
		Case ">="
			Return A >= B
	End Select

	Return False
End Sub

Private Sub GetBasicValue(Expression As String) As String
	Expression = Expression.Trim

	Dim QUOTES As String = Chr(34)

	'String literal.
	If Expression.StartsWith(QUOTES) And Expression.EndsWith(QUOTES) And Expression.Length >= 2 Then
		Return Expression.SubString2(1, Expression.Length - 1)
	End If

	'Variable.
	Dim VariableName As String = Expression.ToUpperCase

	If Variables.ContainsKey(VariableName) Then
		Return Variables.Get(VariableName)
	End If

	'Numeric literal or other value.
	Return Expression
End Sub

Private Sub ParseExpression As Double
	Dim Result As Double = ParseTerm

	Do While ExprPos < ExprText.Length And ExprError = False
		SkipSpaces

		If ExprPos >= ExprText.Length Then Exit

		Dim Op As String = ExprText.SubString2(ExprPos, ExprPos + 1)

		If Op = "+" Or Op = "-" Then
			ExprPos = ExprPos + 1

			Dim Value As Double = ParseTerm

			If Op = "+" Then
				Result = Result + Value
			Else
				Result = Result - Value
			End If
		Else
			Exit
		End If
	Loop

	Return Result
End Sub

Private Sub ParseTerm As Double
	Dim Result As Double = ParseFactor

	Do While ExprPos < ExprText.Length And ExprError = False
		SkipSpaces

		If ExprPos >= ExprText.Length Then Exit

		Dim Op As String = ExprText.SubString2(ExprPos, ExprPos + 1)

		If Op = "*" Or Op = "/" Then
			ExprPos = ExprPos + 1

			Dim Value As Double = ParseFactor

			If Op = "*" Then
				Result = Result * Value
			Else
				If Value = 0 Then
					ExprError = True
					Return 0
				End If

				Result = Result / Value
			End If
		Else
			Exit
		End If
	Loop

	Return Result
End Sub

Private Sub ParseFactor As Double
	SkipSpaces

	If ExprPos >= ExprText.Length Then
		ExprError = True
		Return 0
	End If

	Dim Ch As String = ExprText.SubString2(ExprPos, ExprPos + 1)

	'Unary minus.
	If Ch = "-" Then
		ExprPos = ExprPos + 1
		Return -ParseFactor
	End If

	'Unary plus.
	If Ch = "+" Then
		ExprPos = ExprPos + 1
		Return ParseFactor
	End If

	'Parenthesized expression.
	If Ch = "(" Then
		ExprPos = ExprPos + 1

		Dim Result As Double = ParseExpression

		SkipSpaces

		If ExprPos >= ExprText.Length Then
			ExprError = True
			Return 0
		End If

		If ExprText.SubString2(ExprPos, ExprPos + 1) <> ")" Then
			ExprError = True
			Return 0
		End If

		ExprPos = ExprPos + 1
		Return Result
	End If

	'Read a number or variable.
	Dim StartPos As Int = ExprPos

	Do While ExprPos < ExprText.Length
		Ch = ExprText.SubString2(ExprPos, ExprPos + 1)

		If (Ch.CompareTo("0") >= 0 And Ch.CompareTo("9") <= 0) Or Ch = "." Then
			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop

	If ExprPos > StartPos Then
		Dim NumberText As String = ExprText.SubString2(StartPos, ExprPos)

		If IsNumber(NumberText) Then Return NumberText

		ExprError = True
		Return 0
	End If

	'Variable name.
	Do While ExprPos < ExprText.Length
		Ch = ExprText.SubString2(ExprPos, ExprPos + 1)

		If (Ch.CompareTo("A") >= 0 And Ch.CompareTo("Z") <= 0) Or _
   			(Ch.CompareTo("a") >= 0 And Ch.CompareTo("z") <= 0) Or Ch = "$" Then
   			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop

	If ExprPos = StartPos Then
		ExprError = True
		Return 0
	End If

	Dim VariableName As String = ExprText.SubString2(StartPos, ExprPos).ToUpperCase

	If Variables.ContainsKey(VariableName) = False Then
		ExprError = True
		Return 0
	End If

	Dim VariableValue As String = Variables.Get(VariableName)
	Log("FACTOR: Variable=" & VariableName & ", Value=" & VariableValue)
	
	If IsNumber(VariableValue) = False Then
		ExprError = True
		Return 0
	End If

	Return VariableValue
End Sub

Private Sub SkipSpaces
	Do While ExprPos < ExprText.Length
		If ExprText.SubString2(ExprPos, ExprPos + 1) = " " Then
			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop
End Sub

Private Sub EvaluateNumericExpression(Expression As String) As Double
	ExprText = Expression.ToUpperCase
	ExprPos = 0
	ExprError = False

	Dim Result As Double = ParseExpression

	SkipSpaces

	If ExprPos <> ExprText.Length Then ExprError = True

	Return Result
End Sub

Private Sub IsStringExpression(Expression As String) As Boolean
	Expression = Expression.Trim

	If Expression.StartsWith(Chr(34)) Then Return True
	If Expression.EndsWith("$") Then Return True

	Return False
End Sub

Private Sub ExecuteFor(LineCode As String, BodyPosition As Int) As Boolean

	Dim UpperLine As String = LineCode.ToUpperCase.Trim

	Dim EqualPos As Int = UpperLine.IndexOf("=")
	Dim ToPos As Int = UpperLine.IndexOf(" TO ")
	Dim StepPos As Int = UpperLine.IndexOf(" STEP ")

	If EqualPos < 0 Or ToPos < 0 Or ToPos < EqualPos Then Return False

	Dim VariableName As String = UpperLine.SubString2(4, EqualPos).Trim

	'FOR variables must be single letters.
	If VariableName.Length <> 1 Then Return False

	If VariableName.CompareTo("A") < 0 Or VariableName.CompareTo("Z") > 0 Then Return False

	Dim StartExpression As String = LineCode.SubString2(EqualPos + 1, ToPos).Trim

	Dim LimitExpression As String

	If StepPos >= 0 Then
		LimitExpression = LineCode.SubString2(ToPos + 4, StepPos).Trim
	Else
		LimitExpression = LineCode.SubString(ToPos + 4).Trim
	End If

	Dim StepExpression As String = "1"

	If StepPos >= 0 Then
		StepExpression = LineCode.SubString(StepPos + 6).Trim
	End If

	If StartExpression = "" Or LimitExpression = "" Or StepExpression = "" Then Return False

	Dim StartValue As Double = EvaluateNumericExpression(StartExpression)
	If ExprError Then Return False

	Dim LimitValue As Double = EvaluateNumericExpression(LimitExpression)
	If ExprError Then Return False

	Dim StepValue As Double = EvaluateNumericExpression(StepExpression)
	If ExprError Or StepValue = 0 Then Return False

	Variables.Put(VariableName, NumberFormat(StartValue, 1, 6))

	'Check whether the loop should execute.
	If (StepValue > 0 And StartValue > LimitValue) Or _
   (StepValue < 0 And StartValue < LimitValue) Then

		Dim NextPosition As Int = FindNextPosition(VariableName)

		If NextPosition < 0 Then Return False

		RunPosition = NextPosition
		Return True
	End If

	Dim LoopData As Map
	LoopData.Initialize
	LoopData.Put("Variable", VariableName)
	LoopData.Put("Limit", LimitValue)
	LoopData.Put("Step", StepValue)
	LoopData.Put("BodyPosition", BodyPosition)

	ForStack.Add(LoopData)

	Return True

End Sub

Private Sub ExecuteNext(LineCode As String) As Boolean

	If ForStack.IsInitialized = False Or ForStack.Size = 0 Then Return False

	Dim LoopData As Map = ForStack.Get(ForStack.Size - 1)

	Dim VariableName As String = LoopData.Get("Variable")
	Dim NextVariable As String = LineCode.SubString(4).Trim.ToUpperCase

	If NextVariable <> "" And NextVariable <> VariableName Then Return False

	Dim CurrentValue As Double = Variables.Get(VariableName)
	Dim LimitValue As Double = LoopData.Get("Limit")
	Dim StepValue As Double = LoopData.Get("Step")

	CurrentValue = CurrentValue + StepValue

	Variables.Put(VariableName, NumberFormat(CurrentValue, 1, 6))

	Dim ContinueLoop As Boolean

	If StepValue > 0 Then
		ContinueLoop = CurrentValue <= LimitValue
	Else
		ContinueLoop = CurrentValue >= LimitValue
	End If

	If ContinueLoop Then
		RunPosition = LoopData.Get("BodyPosition")
	Else
		ForStack.RemoveAt(ForStack.Size - 1)
	End If

	Return True

End Sub

Private Sub FindNextPosition(VariableName As String) As Int

	Dim Nesting As Int = 0

	For i = RunPosition To RunLines.Size - 1

		Dim LineNumber As Int = RunLines.Get(i)
		Dim LineCode As String = ProgramLines.Get(LineNumber)
		Dim UpperLine As String = LineCode.ToUpperCase.Trim

		If UpperLine.StartsWith("FOR ") Then
			Nesting = Nesting + 1

		Else If UpperLine = "NEXT" Or UpperLine.StartsWith("NEXT ") Then

			If Nesting = 0 Then
				Dim NextVariable As String = UpperLine.SubString(4).Trim

				If NextVariable = "" Or NextVariable = VariableName Then
					Return i + 1
				End If
			Else
				Nesting = Nesting - 1
			End If

		End If

	Next

	Return -1

End Sub

