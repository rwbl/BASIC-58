﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

#Macro: Title, Export B4XPages, ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	' Retro BASIC – A tiny BASIC interpreter inspired by Commodore 64 / MEGA65 BASIC.
	Private VERSION As String = "MonoBASIC v20261114 BETA"

	Private fx As JFX
	Private xui As XUI

	Private Root As B4XView
	Private btnExecute As B4XView
	Private lblStatus As B4XView
	Private txtCommand As B4XView
	Private txtScreen As B4XView

	' Constants
	Private MAX_VAR_LENGTH As Int = 8

	Private ProgramDir As String
	Private ProgramLines As Map
	
	Private Variables As Map

	'Program execution state
	Private RunLines As List
	Private RunPosition As Int

	'INPUT handling
	Private WaitingForInput As Boolean
	Private InputVariables As List
	Private InputPrompt As String
	'Arithmetic expression parser
	Private ExprText As String
	Private ExprPos As Int
	Private ExprError As Boolean

	'FOR / NEXT handling
	Private ForStack As List

	'GOSUB / RETURN handling
	Private GosubStack As List

	'Error handling.
	Private ErrorHandlerLine As Int				'BASIC line number of the error handler
	Private ErrorHandlerEnabled As Boolean		'Indicates whether an error handler Is registered
	Private ErrorHandlerRunning As Boolean		'Prevents recursive error handling
	Private ErrorLinePosition As Int			'Position of the statement that caused the error
	Private ErrorNextPosition As Int			'Position of the following statement
	Private ErrorMessage As String				'Description of the last error
	Private ErrorCode As Int
	Private ErrorLineNumber As Int
End Sub

Public Sub Initialize
'	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")
	
	ProgramLines.Initialize
	RunLines.Initialize
	Variables.Initialize
	
	'Create RetroBasic data directory.
	ProgramDir = File.DirApp
	' File.Combine(File.DirApp, "RetroBasic")
	' File.MakeDir(File.DirUserHome, "RetroBasic")
	
	' UI
	B4XPages.SetTitle(Me, VERSION)
	B4XPages.GetNativeParent(Me).Resizable = False
	lblStatus.Text = "READY"
	
	' For tests
	txtCommand.Text = "LOAD"
	txtCommand_Action
	txtCommand.Text = "LIST"
	txtCommand_Action
	txtCommand.Text = "RUN"
	txtCommand_Action
	
	InitializeUIStyle
	
	' Welcome Message
	' InitializeScreen
End Sub

Private Sub InitializeUIStyle
	'--------------------------------------------------
	' Main application
	'--------------------------------------------------
	CSSUtils.SetBackgroundColor(Root, fx.Colors.From32Bit(0xFFDCD6C8))
	' Root.SetColorAndBorder(xui.Color_ARGB(0xFF,0xDC,0xD6,0xC8), 2, xui.Color_ARGB(0xFF,0x4A,0x48,0x45), 0)

	'--------------------------------------------------
	' Terminal screen - VT220 Amber
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtScreen, "-fx-control-inner-background", "#191713")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-text-fill", "#FFBF69")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-fill", "#80613A")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-highlight-text-fill", "#FFFFFF")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-color", "#80613A")
	CSSUtils.SetStyleProperty(txtScreen, "-fx-border-width", "2")

	txtScreen.Font = fx.CreateFont("Consolas", 16, False, False)

	'--------------------------------------------------
	' Command input
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(txtCommand, "-fx-background-color", "#211B13")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-text-fill", "#FFBF69")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-prompt-text-fill", "#C9954A")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-border-color", "#80613A")
	CSSUtils.SetStyleProperty(txtCommand, "-fx-border-width", "1")

	txtCommand.Font = fx.CreateFont("Consolas", 17, False, False)

	'--------------------------------------------------
	' Execute button
	'--------------------------------------------------
	CSSUtils.SetStyleProperty(btnExecute, "-fx-background-color", "#58544E")	'"#E0E2DC")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-text-fill", "#F2EFE9")			' "#303830")
	CSSUtils.SetStyleProperty(btnExecute, "-fx-border-color", "#8B9489")

	'--------------------------------------------------
	' Status
	'--------------------------------------------------
	lblStatus.Font = fx.CreateFont("Consolas", 12, True, False)
	' CSSUtils.SetStyleProperty(lblStatus, "-fx-text-fill", "#465448")
	CSSUtils.SetStyleProperty(lblStatus, "-fx-text-fill", "#4A4845")

End Sub

Private Sub InitializeScreen	'ignore

	PrintText("**** RETRO BASIC ****")
	PrintText("")
	PrintText("B4J BASIC INTERPRETER")
	PrintText("")
	PrintText("TYPE HELP FOR COMMANDS")
	PrintText("")
	PrintText("READY.")

	lblStatus.Text = "READY."
End Sub

Private Sub btnExecute_Click
    ProcessInput
End Sub

Private Sub txtCommand_Action
    ProcessInput
End Sub

Private Sub ProcessInput
	Dim Command As String = txtCommand.Text.Trim

	If Command = "" Then Return

	Log("INPUT: " & Command)

	txtCommand.Text = ""

	'If the BASIC program is waiting for INPUT,
	'treat the entered text as the variable value.
	'If the BASIC program is waiting for INPUT.
	If WaitingForInput Then

		Dim InputValues As List
		InputValues.Initialize

		Dim CurrentValue As StringBuilder
		CurrentValue.Initialize

		Dim InQuotes As Boolean = False

		'Split entered values at commas outside quotes.
		For i = 0 To Command.Length - 1
			Dim CurrentChar As String = Command.SubString2(i, i + 1)

			If CurrentChar = Chr(34) Then
				InQuotes = Not(InQuotes)
			End If

			If CurrentChar = "," And InQuotes = False Then
				InputValues.Add(CurrentValue.ToString.Trim)
				CurrentValue.Initialize
			Else
				CurrentValue.Append(CurrentChar)
			End If
		Next

		InputValues.Add(CurrentValue.ToString.Trim)

		'Validate input.
		Dim ValidInput As Boolean = True

		If InQuotes Or InputValues.Size <> InputVariables.Size Then
			ValidInput = False
		Else
			For i = 0 To InputVariables.Size - 1
				Dim VariableName As String = InputVariables.Get(i)
				Dim InputValue As String = InputValues.Get(i)

				If VariableName.EndsWith("$") Then
					If InputValue.StartsWith(Chr(34)) Or InputValue.EndsWith(Chr(34)) Then
						If InputValue.StartsWith(Chr(34)) And InputValue.EndsWith(Chr(34)) And InputValue.Length >= 2 Then
							InputValue = InputValue.SubString2(1, InputValue.Length - 1)
							InputValues.Set(i, InputValue)
						Else
							ValidInput = False
						End If
					End If
				Else
					If IsNumber(InputValue) = False Then
						ValidInput = False
					End If
				End If
			Next
		End If

		If ValidInput = False Then
			PrintText("?REDO FROM START")
			PrintText(InputPrompt & "?")
			txtCommand.RequestFocus
			Return
		End If

		'Assign values to variables.
		For i = 0 To InputVariables.Size - 1
			Dim VariableName As String = InputVariables.Get(i)
			Dim InputValue As String = InputValues.Get(i)

			Variables.Put(VariableName, InputValue)
		Next

		WaitingForInput = False

		ContinueProgram

		txtCommand.RequestFocus
		Return
	End If
	
	ExecuteCommand(Command)

	txtCommand.RequestFocus
End Sub

Private Sub ExecuteCommand(Command As String)
	Command = Command.Trim

	If Command = "" Then Return

	Dim UpperCommand As String = Command.ToUpperCase

	'Check whether this is a numbered BASIC program line.
	Dim SpacePos As Int = Command.IndexOf(" ")

	If SpacePos > 0 Then
		Dim FirstToken As String = Command.SubString2(0, SpacePos)

		If IsNumber(FirstToken) Then
			Dim LineNumber As Int = FirstToken
			Dim LineCode As String = Command.SubString(SpacePos + 1).Trim

			If LineCode = "" Then
				ProgramLines.Remove(LineNumber)
			Else
				ProgramLines.Put(LineNumber, LineCode)
				PrintText("STORED: " & LineNumber & " = " & LineCode)
			End If

			Return
		End If
	End If

	' Load and Save
	If UpperCommand = "SAVE" Or UpperCommand.StartsWith("SAVE ") Then
		SaveProgram(Command.SubString(4).Trim)
		Return
	End If

	If UpperCommand = "LOAD" Or UpperCommand.StartsWith("LOAD ") Then
		LoadProgram(Command.SubString(4).Trim)
		Return
	End If

	' Other commands
	Select Case UpperCommand
		Case "CLS"
			txtScreen.Text = ""

		Case "HELP"
			PrintText("AVAILABLE COMMANDS:")
			PrintText("PRINT <TEXT>")
			PrintText("LIST")
			PrintText("RUN")
			PrintText("CLS")
			PrintText("HELP")

		Case "LIST"
			ListProgram

		Case "RUN"
			RunProgram

		Case "NEW"
			ProgramLines.Clear
			Variables.Clear
			WaitingForInput = False
			PrintText("NEW PROGRAM")
			
		Case Else
			If UpperCommand.StartsWith("PRINT ") Then
				PrintBasicText(Command)
			Else
				PrintText("?SYNTAX ERROR")
			End If
	End Select

	lblStatus.Text = "READY."
End Sub

Private Sub ExecuteLet(LineCode As String) As Boolean
	Dim EqualPos As Int = LineCode.IndexOf("=")

	If EqualPos < 0 Then Return False

	Dim VariableName As String = LineCode.SubString2(4, EqualPos).Trim.ToUpperCase
	Dim Expression As String = LineCode.SubString(EqualPos + 1).Trim

	If VariableName = "" Or Expression = "" Then Return False

	If VariableName.Length > MAX_VAR_LENGTH Then Return False

	Dim FirstChar As String = VariableName.SubString2(0, 1)

	If FirstChar.CompareTo("A") < 0 Or FirstChar.CompareTo("Z") > 0 Then Return False

	If VariableName.Length = MAX_VAR_LENGTH And VariableName.EndsWith("$") = False Then Return False

	'String variable.
	If VariableName.EndsWith("$") Then

		Dim StringValue As String = EvaluateStringExpression(Expression)

		If ExprError Then
			PrintText("?ILLEGAL STRING EXPRESSION")
			Return False
		End If

		Variables.Put(VariableName, StringValue)
		Return True
	End If

	'Numeric expression.
	Dim Result As Double = 0

	Log("LET: Variable=" & VariableName & ", Expression=" & Expression)

	Result = EvaluateNumericExpression(Expression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Variables.Put(VariableName, NumberFormat(Result, 1, 6))

	Return True
End Sub

Private Sub RunProgram
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	Variables.Clear
	WaitingForInput = False

	PrintText("")
	PrintText("RUNNING...")
	PrintText("")

	'Get program line numbers in numerical order.
	RunLines.Initialize

	For Each Key As Object In ProgramLines.Keys
		RunLines.Add(Key)
	Next

	RunLines.Sort(True)

	RunPosition = 0

	If ForStack.IsInitialized = False Then
		ForStack.Initialize
	Else
		ForStack.Clear
	End If
	
	If GosubStack.IsInitialized = False Then
		GosubStack.Initialize
	Else
		GosubStack.Clear
	End If
	
	ContinueProgram
End Sub

Private Sub ContinueProgram

	Do While RunPosition < RunLines.Size

		Dim LineNumber As Int = RunLines.Get(RunPosition)
		RunPosition = RunPosition + 1

		Dim LineCode As String = ProgramLines.Get(LineNumber)
		Dim UpperLine As String = LineCode.ToUpperCase.Trim

		Select Case True

			Case UpperLine = "END"
				RunPosition = RunLines.Size

			Case UpperLine = "REM" Or UpperLine.StartsWith("REM ")
				'Comment.

			Case UpperLine.StartsWith("ON ERROR ")
				If ExecuteOnError(LineCode) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine = "RESUME" Or UpperLine = "RESUME NEXT"
				If ExecuteResume(LineCode) = False Then
					If HandleProgramError("?RESUME WITHOUT ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine.StartsWith("ON ")
				If ExecuteOn(LineCode) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine.StartsWith("GOSUB ")
				Dim TargetText As String = LineCode.SubString(6).Trim

				If IsNumber(TargetText) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

				Dim TargetLine As Int = TargetText

				GosubStack.Add(RunPosition)

				If JumpToLine(TargetLine) = False Then
					GosubStack.RemoveAt(GosubStack.Size - 1)

					If HandleProgramError("?UNDEFINED LINE " & TargetLine) Then Continue
					Exit
				End If

			Case UpperLine.StartsWith("GOTO ")
				Dim TargetText As String = LineCode.SubString(5).Trim

				If IsNumber(TargetText) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

				Dim TargetLine As Int = TargetText

				If JumpToLine(TargetLine) = False Then
					If HandleProgramError("?UNDEFINED LINE " & TargetLine) Then Continue
					Exit
				End If

			Case UpperLine.StartsWith("IF ")
				Dim ThenPos As Int = UpperLine.IndexOf("THEN")

				If ThenPos < 0 Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

				Dim Condition As String = LineCode.SubString2(3, ThenPos).Trim
				Dim TargetText As String = LineCode.SubString(ThenPos + 4).Trim

				If IsNumber(TargetText) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

				If EvaluateCondition(Condition) Then
					Dim TargetLine As Int = TargetText

					If JumpToLine(TargetLine) = False Then
						If HandleProgramError("?UNDEFINED LINE " & TargetLine) Then Continue
						Exit
					End If
				End If

			Case UpperLine.StartsWith("PRINT ")
				PrintBasicText(LineCode)

			Case UpperLine.StartsWith("INPUT ")
				If ExecuteInput(LineCode) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

				WaitingForInput = True
				Return

			Case UpperLine.StartsWith("LET ")
				If ExecuteLet(LineCode) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine.StartsWith("FOR ")
				If ExecuteFor(LineCode, RunPosition) = False Then
					If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine = "NEXT" Or UpperLine.StartsWith("NEXT ")
				If ExecuteNext(LineCode) = False Then
					If HandleProgramError("?NEXT WITHOUT FOR IN LINE " & LineNumber) Then Continue
					Exit
				End If

			Case UpperLine = "RETURN"
				If GosubStack.Size = 0 Then
					If HandleProgramError("?RETURN WITHOUT GOSUB IN LINE " & LineNumber) Then Continue
					Exit
				End If

				RunPosition = GosubStack.Get(GosubStack.Size - 1)
				GosubStack.RemoveAt(GosubStack.Size - 1)

			Case Else
				If HandleProgramError("?SYNTAX ERROR IN LINE " & LineNumber) Then Continue
				Exit

		End Select

	Loop

	WaitingForInput = False
	PrintText("")
	PrintText("READY.")
End Sub

Private Sub PrintBasicText(LineCode As String)
	Dim Value As String = LineCode.SubString(6).Trim
	Dim Items As List
	Items.Initialize

	Dim CurrentItem As StringBuilder
	CurrentItem.Initialize

	Dim InQuotes As Boolean = False
	Dim BracketLevel As Int = 0
	Dim LastSeparator As String = ""

	'Split PRINT arguments.
	For i = 0 To Value.Length - 1
		Dim CurrentChar As String = Value.SubString2(i, i + 1)

		If CurrentChar = Chr(34) Then
			InQuotes = Not(InQuotes)
		Else If InQuotes = False Then
			If CurrentChar = "(" Then BracketLevel = BracketLevel + 1
			If CurrentChar = ")" Then BracketLevel = BracketLevel - 1

			If (CurrentChar = ";" Or CurrentChar = ",") And BracketLevel = 0 Then
				Items.Add(CurrentItem.ToString.Trim)
				Items.Add(CurrentChar)
				CurrentItem.Initialize
				LastSeparator = CurrentChar
				Continue
			End If
		End If

		CurrentItem.Append(CurrentChar)
		LastSeparator = ""
	Next

	If CurrentItem.Length > 0 Then Items.Add(CurrentItem.ToString.Trim)

	'Print arguments.
	Dim Output As String = ""
	Dim Column As Int = 0

	For Each Item As String In Items
		If Item = ";" Then
			Continue

		Else If Item = "," Then
			Dim Spaces As Int = 14 - (Column Mod 14)
			Output = Output & SpaceString(Spaces)
			Column = Column + Spaces

		Else If Item.ToUpperCase.StartsWith("TAB(") And Item.EndsWith(")") Then
			Dim Argument As String = Item.SubString2(4, Item.Length - 1)
			Dim TargetColumn As Double = EvaluateNumericExpression(Argument)

			If ExprError Or TargetColumn < 1 Then
				Output = Output & "?ILLEGAL TAB"
			Else
				Dim Spaces As Int = TargetColumn - 1 - Column
				If Spaces > 0 Then Output = Output & SpaceString(Spaces)
				If Spaces > 0 Then Column = Column + Spaces
			End If

		Else If Item.ToUpperCase.StartsWith("SPC(") And Item.EndsWith(")") Then
			Dim Argument As String = Item.SubString2(4, Item.Length - 1)
			Dim SpaceCount As Double = EvaluateNumericExpression(Argument)

			If ExprError Or SpaceCount < 0 Then
				Output = Output & "?ILLEGAL SPC"
			Else
				Dim Spaces As Int = SpaceCount
				Output = Output & SpaceString(Spaces)
				Column = Column + Spaces
			End If

		Else
			Dim ItemValue As String = EvaluatePrintItem(Item)
			Output = Output & ItemValue
			Column = Column + ItemValue.Length
		End If
	Next

	'Print result.
	If LastSeparator = ";" Or LastSeparator = "," Then
		txtScreen.Text = txtScreen.Text & Output
	Else
		PrintText(Output)
	End If
End Sub

Private Sub EvaluatePrintItem(Item As String) As String
	If Item = "" Then Return ""

	'String expression.
	If IsStringExpressionForPrint(Item) Then
		Dim StringResult As String = EvaluateStringExpression(Item)

		If ExprError Then Return "?ILLEGAL STRING EXPRESSION"

		Return StringResult
	End If

	'Numeric expression.
	Dim NumericResult As Double = EvaluateNumericExpression(Item)

	If ExprError Then Return "?ILLEGAL EXPRESSION"

	Return NumberFormat(NumericResult, 1, 6)
End Sub

Private Sub PrintText(Value As String)
    txtScreen.Text = txtScreen.Text & Value & CRLF
End Sub

Private Sub ListProgram
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	'Copy Map keys into a List.
	Dim LineNumbers As List
	LineNumbers.Initialize

	For Each Key As Object In ProgramLines.Keys
		LineNumbers.Add(Key)
	Next

	'Sort line numbers numerically.
	LineNumbers.Sort(True)

	'Display the BASIC program.
	For Each LineNumber As Int In LineNumbers
		Dim LineCode As String = ProgramLines.Get(LineNumber)
		PrintText(LineNumber & " " & LineCode)
	Next
End Sub

Private Sub SaveProgram(FileName As String)
	If ProgramLines.Size = 0 Then
		PrintText("NO PROGRAM")
		Return
	End If

	If FileName = "" Then FileName = "PROGRAM.BAS"

	If FileName.Contains("/") Or FileName.Contains("\") Then
		PrintText("?INVALID FILE NAME")
		Return
	End If

	If FileName.Contains(".") = False Then
		FileName = FileName & ".bas"
	End If

	Try
		Dim LineNumbers As List
		LineNumbers.Initialize

		For Each Key As Object In ProgramLines.Keys
			LineNumbers.Add(Key)
		Next

		LineNumbers.Sort(True)

		Dim SavedLines As List
		SavedLines.Initialize

		For Each LineNumber As Int In LineNumbers
			Dim LineCode As String = ProgramLines.Get(LineNumber)
			SavedLines.Add(LineNumber & " " & LineCode)
		Next

		File.WriteList(ProgramDir, FileName, SavedLines)

		PrintText("SAVED: " & FileName)

	Catch
		PrintText("?SAVE ERROR")
		Log(LastException)
	End Try
End Sub

Private Sub LoadProgram(FileName As String)
	If FileName = "" Then FileName = "PROGRAM.BAS"

	If FileName.Contains("/") Or FileName.Contains("\") Then
		PrintText("?INVALID FILE NAME")
		Return
	End If

	If FileName.Contains(".") = False Then
		FileName = FileName & ".bas"
	End If

	If File.Exists(ProgramDir, FileName) = False Then
		PrintText("?FILE NOT FOUND: " & FileName)
		Return
	End If

	Try
		Dim SavedLines As List = File.ReadList(ProgramDir, FileName)

		'Clear the current program.
		ProgramLines.Clear

		'Restore the saved BASIC program.
		For Each SavedLine As String In SavedLines
			Dim SpacePos As Int = SavedLine.IndexOf(" ")

			If SpacePos > 0 Then
				Dim NumberText As String = SavedLine.SubString2(0, SpacePos)

				If IsNumber(NumberText) Then
					Dim LineNumber As Int = NumberText
					Dim LineCode As String = SavedLine.SubString(SpacePos + 1).Trim

					If LineCode <> "" Then
						ProgramLines.Put(LineNumber, LineCode)
					End If
				End If
			End If
		Next

		PrintText("LOADED: " & FileName)
		PrintText("LINES: " & ProgramLines.Size)

	Catch
		PrintText("?LOAD ERROR")
		Log(LastException)
	End Try
End Sub

Private Sub JumpToLine(TargetLine As Int) As Boolean
	Dim Position As Int = FindRunPosition(TargetLine)

	If Position < 0 Then Return False

	RunPosition = Position
	Return True
End Sub

Private Sub EvaluateCondition(Condition As String) As Boolean
	Dim Operators As List = Array As String("<=", ">=", "<>", "=", "<", ">")

	Dim OperatorFound As String = ""
	Dim OperatorPos As Int = -1

	'Find the comparison operator.
	For Each Op As String In Operators
		OperatorPos = Condition.IndexOf(Op)

		If OperatorPos >= 0 Then
			OperatorFound = Op
			Exit
		End If
	Next

	If OperatorPos < 0 Then
		PrintText("?INVALID CONDITION")
		Return False
	End If

	Dim LeftExpression As String = Condition.SubString2(0, OperatorPos).Trim
	Dim RightExpression As String = Condition.SubString(OperatorPos + OperatorFound.Length).Trim

	'String comparison.
	If IsStringExpression(LeftExpression) Or IsStringExpression(RightExpression) Then

		Dim LeftValue As String = GetBasicValue(LeftExpression)
		Dim RightValue As String = GetBasicValue(RightExpression)

		Select Case OperatorFound
			Case "="
				Return LeftValue = RightValue
			Case "<>"
				Return LeftValue <> RightValue
			Case Else
				PrintText("?INVALID STRING COMPARISON")
				Return False
		End Select
	End If

	'Numeric comparison.
	Dim A As Double = EvaluateNumericExpression(LeftExpression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Dim B As Double = EvaluateNumericExpression(RightExpression)

	If ExprError Then
		PrintText("?ILLEGAL EXPRESSION")
		Return False
	End If

	Select Case OperatorFound
		Case "="
			Return A = B
		Case "<>"
			Return A <> B
		Case "<"
			Return A < B
		Case ">"
			Return A > B
		Case "<="
			Return A <= B
		Case ">="
			Return A >= B
	End Select

	Return False
End Sub

Private Sub GetBasicValue(Expression As String) As String
	Expression = Expression.Trim

	Dim QUOTES As String = Chr(34)

	'String literal.
	If Expression.StartsWith(QUOTES) And Expression.EndsWith(QUOTES) And Expression.Length >= 2 Then
		Return Expression.SubString2(1, Expression.Length - 1)
	End If

	'Variable.
	Dim VariableName As String = Expression.ToUpperCase

	If Variables.ContainsKey(VariableName) Then
		Return Variables.Get(VariableName)
	End If

	'Numeric literal or other value.
	Return Expression
End Sub

Private Sub ParseExpression As Double
	Dim Result As Double = ParseTerm

	Do While ExprPos < ExprText.Length And ExprError = False
		SkipSpaces

		If ExprPos >= ExprText.Length Then Exit

		Dim Op As String = ExprText.SubString2(ExprPos, ExprPos + 1)

		If Op = "+" Or Op = "-" Then
			ExprPos = ExprPos + 1

			Dim Value As Double = ParseTerm

			If Op = "+" Then
				Result = Result + Value
			Else
				Result = Result - Value
			End If
		Else
			Exit
		End If
	Loop

	Return Result
End Sub

Private Sub ParseTerm As Double
	Dim Result As Double = ParseFactor

	Do While ExprPos < ExprText.Length And ExprError = False
		SkipSpaces

		If ExprPos >= ExprText.Length Then Exit

		Dim Op As String = ExprText.SubString2(ExprPos, ExprPos + 1)

		If Op = "*" Or Op = "/" Then
			ExprPos = ExprPos + 1

			Dim Value As Double = ParseFactor

			If Op = "*" Then
				Result = Result * Value
			Else
				If Value = 0 Then
					ExprError = True
					Return 0
				End If

				Result = Result / Value
			End If
		Else
			Exit
		End If
	Loop

	Return Result
End Sub



Private Sub ParseFactor As Double
	SkipSpaces

	If ExprPos >= ExprText.Length Then
		ExprError = True
		Return 0
	End If

	Dim Ch As String = ExprText.SubString2(ExprPos, ExprPos + 1)

	'Unary minus.
	If Ch = "-" Then
		ExprPos = ExprPos + 1
		Return -ParseFactor
	End If

	'Unary plus.
	If Ch = "+" Then
		ExprPos = ExprPos + 1
		Return ParseFactor
	End If

	'Parenthesized expression.
	If Ch = "(" Then
		ExprPos = ExprPos + 1

		Dim Result As Double = ParseExpression

		SkipSpaces

		If ExprPos >= ExprText.Length Then
			ExprError = True
			Return 0
		End If

		If ExprText.SubString2(ExprPos, ExprPos + 1) <> ")" Then
			ExprError = True
			Return 0
		End If

		ExprPos = ExprPos + 1
		Return Result
	End If

	'Read a number.
	Dim StartPos As Int = ExprPos

	Do While ExprPos < ExprText.Length
		Ch = ExprText.SubString2(ExprPos, ExprPos + 1)

		If (Ch.CompareTo("0") >= 0 And Ch.CompareTo("9") <= 0) Or Ch = "." Then
			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop

	If ExprPos > StartPos Then
		Dim NumberText As String = ExprText.SubString2(StartPos, ExprPos)

		If IsNumber(NumberText) Then Return NumberText

		ExprError = True
		Return 0
	End If

	'Read a variable or function name.
	Do While ExprPos < ExprText.Length
		Ch = ExprText.SubString2(ExprPos, ExprPos + 1)

		If (Ch.CompareTo("A") >= 0 And Ch.CompareTo("Z") <= 0) Or _
			(Ch.CompareTo("a") >= 0 And Ch.CompareTo("z") <= 0) Or Ch = "$" Then
			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop

	If ExprPos = StartPos Then
		ExprError = True
		Return 0
	End If

	Dim Name As String = ExprText.SubString2(StartPos, ExprPos).ToUpperCase

	SkipSpaces

	If ExprPos < ExprText.Length Then
		Log("NEXT CHAR: " & ExprText.SubString2(ExprPos, ExprPos + 1))
	End If

	'Function.
	If ExprPos < ExprText.Length Then
		If ExprText.SubString2(ExprPos, ExprPos + 1) = "(" Then

			ExprPos = ExprPos + 1

			'INSTR: Search for a substring.
			If Name = "INSTR" Then
				Dim SearchText As String = ReadStringFunctionArgument

				If ExprError Then Return 0

				SkipSpaces

				If ExprPos >= ExprText.Length Or _
					ExprText.SubString2(ExprPos, ExprPos + 1) <> "," Then
					ExprError = True
					Return 0
				End If

				ExprPos = ExprPos + 1

				Dim SearchFor As String = ReadStringFunctionArgument

				If ExprError Then Return 0

				SkipSpaces

				If ExprPos >= ExprText.Length Or _
					ExprText.SubString2(ExprPos, ExprPos + 1) <> ")" Then
					ExprError = True
					Return 0
				End If

				ExprPos = ExprPos + 1

				Dim FoundPosition As Int = SearchText.IndexOf(SearchFor)

				If FoundPosition < 0 Then Return 0

				Return FoundPosition + 1
			End If

			'LEN, VAL and ASC: Evaluate a complete string expression.
			If Name = "LEN" Or Name = "VAL" Or Name = "ASC" Then

				Dim StringArgumentStart As Int = ExprPos
				Dim StringArgumentEnd As Int = -1
				Dim StringBracketLevel As Int = 0
				Dim StringInQuotes As Boolean = False

				'Find the closing bracket of the function.
				Do While ExprPos < ExprText.Length
					Dim ScanChar As String = ExprText.SubString2(ExprPos, ExprPos + 1)

					If ScanChar = Chr(34) Then
						StringInQuotes = Not(StringInQuotes)

					Else If StringInQuotes = False Then
						If ScanChar = "(" Then
							StringBracketLevel = StringBracketLevel + 1

						Else If ScanChar = ")" Then
							If StringBracketLevel = 0 Then
								StringArgumentEnd = ExprPos
								Exit
							Else
								StringBracketLevel = StringBracketLevel - 1
							End If
						End If
					End If

					ExprPos = ExprPos + 1
				Loop

				If StringArgumentEnd < 0 Or StringInQuotes Then
					ExprError = True
					Return 0
				End If

				Dim StringExpressionText As String = _
					ExprText.SubString2(StringArgumentStart, StringArgumentEnd)

				'Move past the closing bracket.
				ExprPos = StringArgumentEnd + 1

				'Evaluate the string expression.
				Dim StringFunctionValue As String = _
					EvaluateStringExpression(StringExpressionText)

				If ExprError Then Return 0

				If Name = "LEN" Then
					Return StringFunctionValue.Length

				Else If Name = "ASC" Then
					If StringFunctionValue.Length = 0 Then
						ExprError = True
						Return 0
					End If

					Return Asc(StringFunctionValue)

				Else
					'VAL: Convert string to number.
					If IsNumber(StringFunctionValue) = False Then
						ExprError = True
						Return 0
					End If

					Return StringFunctionValue
				End If
			End If

			'Mathematical function.
			Dim Argument As Double = ParseExpression

			SkipSpaces

			If ExprError Or ExprPos >= ExprText.Length Then
				ExprError = True
				Return 0
			End If

			If ExprText.SubString2(ExprPos, ExprPos + 1) <> ")" Then
				ExprError = True
				Return 0
			End If

			ExprPos = ExprPos + 1

			Select Case Name
				Case "SQR"
					If Argument < 0 Then
						ExprError = True
						Return 0
					End If
					Return Sqrt(Argument)

				Case "ABS"
					Return Abs(Argument)

				Case "INT"
					Return Floor(Argument)

				Case "SIN"
					Return Sin(Argument * cPI / 180)

				Case "COS"
					Return Cos(Argument * cPI / 180)

				Case "TAN"
					Return Tan(Argument * cPI / 180)

				Case "LOG"
					If Argument <= 0 Then
						ExprError = True
						Return 0
					End If
					Return Logarithm(Argument, cE)

				Case "EXP"
					Return Power(cE, Argument)

				Case "SGN"
					If Argument < 0 Then Return -1
					If Argument > 0 Then Return 1
					Return 0

				Case "RND"
					Return Rnd(0, 1000000) / 1000000

				Case Else
					ExprError = True
					Return 0
			End Select
		End If
	End If

	'Predefined BASIC error variables.
	If Name = "ERR" Then Return ErrorCode
	If Name = "ERL" Then Return ErrorLineNumber

	'Ordinary variable.
	If Variables.ContainsKey(Name) = False Then
		ExprError = True
		Return 0
	End If

	Dim VariableValue As String = Variables.Get(Name)
	Log("FACTOR: Variable=" & Name & ", Value=" & VariableValue)

	If IsNumber(VariableValue) = False Then
		ExprError = True
		Return 0
	End If

	Return VariableValue
End Sub

Private Sub ReadStringFunctionArgument As String
	SkipSpaces

	If ExprPos >= ExprText.Length Then
		ExprError = True
		Return ""
	End If

	Dim CurrentChar As String = ExprText.SubString2(ExprPos, ExprPos + 1)

	'String literal.
	If CurrentChar = Chr(34) Then
		ExprPos = ExprPos + 1

		Dim StartString As Int = ExprPos

		Do While ExprPos < ExprText.Length
			CurrentChar = ExprText.SubString2(ExprPos, ExprPos + 1)

			If CurrentChar = Chr(34) Then Exit

			ExprPos = ExprPos + 1
		Loop

		If ExprPos >= ExprText.Length Then
			ExprError = True
			Return ""
		End If

		Dim StringValue As String = ExprText.SubString2(StartString, ExprPos)

		ExprPos = ExprPos + 1

		Return StringValue
	End If

	'String variable.
	Dim StartVariable As Int = ExprPos

	Do While ExprPos < ExprText.Length
		CurrentChar = ExprText.SubString2(ExprPos, ExprPos + 1)

		If (CurrentChar.CompareTo("A") >= 0 And CurrentChar.CompareTo("Z") <= 0) Or _
			(CurrentChar.CompareTo("a") >= 0 And CurrentChar.CompareTo("z") <= 0) Or _
			IsNumber(CurrentChar) Or CurrentChar = "$" Then

			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop

	Dim VariableName As String = ExprText.SubString2(StartVariable, ExprPos).ToUpperCase

	If VariableName.EndsWith("$") = False Or _
		Variables.ContainsKey(VariableName) = False Then

		ExprError = True
		Return ""
	End If

	Return Variables.Get(VariableName)
End Sub

Private Sub SkipSpaces
	Do While ExprPos < ExprText.Length
		If ExprText.SubString2(ExprPos, ExprPos + 1) = " " Then
			ExprPos = ExprPos + 1
		Else
			Exit
		End If
	Loop
End Sub

Private Sub EvaluateNumericExpression(Expression As String) As Double
	ExprText = Expression.ToUpperCase
	ExprPos = 0
	ExprError = False

	Dim Result As Double = ParseExpression

	SkipSpaces

	If ExprPos <> ExprText.Length Then ExprError = True

	Return Result
End Sub

Private Sub IsStringExpression(Expression As String) As Boolean
	Expression = Expression.Trim

	If Expression.StartsWith(Chr(34)) Then Return True
	If Expression.EndsWith("$") Then Return True

	Return False
End Sub

Private Sub ExecuteFor(LineCode As String, BodyPosition As Int) As Boolean

	Dim UpperLine As String = LineCode.ToUpperCase.Trim

	Dim EqualPos As Int = UpperLine.IndexOf("=")
	Dim ToPos As Int = UpperLine.IndexOf(" TO ")
	Dim StepPos As Int = UpperLine.IndexOf(" STEP ")

	If EqualPos < 0 Or ToPos < 0 Or ToPos < EqualPos Then Return False

	Dim VariableName As String = UpperLine.SubString2(4, EqualPos).Trim

	'FOR variables must be single letters.
	If VariableName.Length <> 1 Then Return False

	If VariableName.CompareTo("A") < 0 Or VariableName.CompareTo("Z") > 0 Then Return False

	Dim StartExpression As String = LineCode.SubString2(EqualPos + 1, ToPos).Trim

	Dim LimitExpression As String

	If StepPos >= 0 Then
		LimitExpression = LineCode.SubString2(ToPos + 4, StepPos).Trim
	Else
		LimitExpression = LineCode.SubString(ToPos + 4).Trim
	End If

	Dim StepExpression As String = "1"

	If StepPos >= 0 Then
		StepExpression = LineCode.SubString(StepPos + 6).Trim
	End If

	If StartExpression = "" Or LimitExpression = "" Or StepExpression = "" Then Return False

	Dim StartValue As Double = EvaluateNumericExpression(StartExpression)
	If ExprError Then Return False

	Dim LimitValue As Double = EvaluateNumericExpression(LimitExpression)
	If ExprError Then Return False

	Dim StepValue As Double = EvaluateNumericExpression(StepExpression)
	If ExprError Or StepValue = 0 Then Return False

	Variables.Put(VariableName, NumberFormat(StartValue, 1, 6))

	'Check whether the loop should execute.
	If (StepValue > 0 And StartValue > LimitValue) Or _
   (StepValue < 0 And StartValue < LimitValue) Then

		Dim NextPosition As Int = FindNextPosition(VariableName)

		If NextPosition < 0 Then Return False

		RunPosition = NextPosition
		Return True
	End If

	Dim LoopData As Map
	LoopData.Initialize
	LoopData.Put("Variable", VariableName)
	LoopData.Put("Limit", LimitValue)
	LoopData.Put("Step", StepValue)
	LoopData.Put("BodyPosition", BodyPosition)

	ForStack.Add(LoopData)

	Return True

End Sub

Private Sub ExecuteNext(LineCode As String) As Boolean

	If ForStack.IsInitialized = False Or ForStack.Size = 0 Then Return False

	Dim LoopData As Map = ForStack.Get(ForStack.Size - 1)

	Dim VariableName As String = LoopData.Get("Variable")
	Dim NextVariable As String = LineCode.SubString(4).Trim.ToUpperCase

	If NextVariable <> "" And NextVariable <> VariableName Then Return False

	Dim CurrentValue As Double = Variables.Get(VariableName)
	Dim LimitValue As Double = LoopData.Get("Limit")
	Dim StepValue As Double = LoopData.Get("Step")

	CurrentValue = CurrentValue + StepValue

	Variables.Put(VariableName, NumberFormat(CurrentValue, 1, 6))

	Dim ContinueLoop As Boolean

	If StepValue > 0 Then
		ContinueLoop = CurrentValue <= LimitValue
	Else
		ContinueLoop = CurrentValue >= LimitValue
	End If

	If ContinueLoop Then
		RunPosition = LoopData.Get("BodyPosition")
	Else
		ForStack.RemoveAt(ForStack.Size - 1)
	End If

	Return True

End Sub

Private Sub FindNextPosition(VariableName As String) As Int

	Dim Nesting As Int = 0

	For i = RunPosition To RunLines.Size - 1

		Dim LineNumber As Int = RunLines.Get(i)
		Dim LineCode As String = ProgramLines.Get(LineNumber)
		Dim UpperLine As String = LineCode.ToUpperCase.Trim

		If UpperLine.StartsWith("FOR ") Then
			Nesting = Nesting + 1

		Else If UpperLine = "NEXT" Or UpperLine.StartsWith("NEXT ") Then

			If Nesting = 0 Then
				Dim NextVariable As String = UpperLine.SubString(4).Trim

				If NextVariable = "" Or NextVariable = VariableName Then
					Return i + 1
				End If
			Else
				Nesting = Nesting - 1
			End If

		End If

	Next

	Return -1

End Sub

Private Sub ExecuteOn(LineCode As String) As Boolean

	Dim UpperLine As String = LineCode.ToUpperCase.Trim

	Dim GotoPos As Int = UpperLine.IndexOf(" GOTO ")
	Dim GosubPos As Int = UpperLine.IndexOf(" GOSUB ")

	Dim IsGosub As Boolean = False
	Dim OperatorPos As Int
	Dim OperatorLength As Int

	If GotoPos >= 0 Then
		OperatorPos = GotoPos
		OperatorLength = 6
	Else If GosubPos >= 0 Then
		OperatorPos = GosubPos
		OperatorLength = 7
		IsGosub = True
	Else
		Return False
	End If

	'Get selector expression.
	Dim Expression As String = LineCode.SubString2(3, OperatorPos).Trim

	Dim Selector As Double = EvaluateNumericExpression(Expression)

	If ExprError Then Return False

	'Get target line list.
	Dim TargetList As String = LineCode.SubString(OperatorPos + OperatorLength)
	Dim Targets() As String = Regex.Split(",", TargetList)

	If Targets.Length = 0 Then Return False

	'Validate all target line numbers.
	For Each Target As String In Targets
		Target = Target.Trim
		If IsNumber(Target) = False Then Return False
	Next

	'BASIC ON selection is 1-based.
	Dim Choice As Int = Selector

	If Choice < 1 Or Choice > Targets.Length Then Return True

	Dim TargetLine As Int = Targets(Choice - 1)

	If IsGosub Then
		'Remember the position of the next BASIC line.
		GosubStack.Add(RunPosition)
	End If

	If JumpToLine(TargetLine) = False Then
		If IsGosub Then
			GosubStack.RemoveAt(GosubStack.Size - 1)
		End If
		Return False
	End If

	Return True

End Sub

Private Sub ExecuteInput(LineCode As String) As Boolean
	Dim Value As String = LineCode.SubString(6).Trim
	Dim QUOTES As String = Chr(34)

	InputPrompt = ""

	'Optional prompt.
	If Value.StartsWith(QUOTES) Then
		Dim QuoteEnd As Int = -1

		For i = 1 To Value.Length - 1
			If Value.SubString2(i, i + 1) = QUOTES Then
				QuoteEnd = i
				Exit
			End If
		Next

		If QuoteEnd < 0 Then Return False

		InputPrompt = Value.SubString2(1, QuoteEnd)

		Value = Value.SubString(QuoteEnd + 1).Trim

		If Value.StartsWith(";") = False Then Return False

		Value = Value.SubString(1).Trim
	End If

	If Value = "" Then Return False

	'Extract variable names.
	InputVariables.Initialize

	Dim CurrentVariable As StringBuilder
	CurrentVariable.Initialize

	For i = 0 To Value.Length - 1
		Dim CurrentChar As String = Value.SubString2(i, i + 1)

		If CurrentChar = "," Then
			If AddInputVariable(CurrentVariable.ToString.Trim) = False Then Return False
			CurrentVariable.Initialize
		Else
			CurrentVariable.Append(CurrentChar)
		End If
	Next

	If AddInputVariable(CurrentVariable.ToString.Trim) = False Then Return False

	'Display prompt.
	PrintText(InputPrompt & "?")

	Return True
End Sub

Private Sub AddInputVariable(VariableName As String) As Boolean
	VariableName = VariableName.ToUpperCase

	If VariableName = "" Or VariableName.Length > 8 Then Return False

	Dim FirstChar As String = VariableName.SubString2(0, 1)

	If FirstChar.CompareTo("A") < 0 Or FirstChar.CompareTo("Z") > 0 Then Return False

	For i = 0 To VariableName.Length - 1
		Dim CurrentChar As String = VariableName.SubString2(i, i + 1)

		If CurrentChar = "$" Then
			If i <> VariableName.Length - 1 Then Return False
		Else If (CurrentChar.CompareTo("A") < 0 Or CurrentChar.CompareTo("Z") > 0) And IsNumber(CurrentChar) = False Then
			Return False
		End If
	Next

	InputVariables.Add(VariableName)

	Return True
End Sub



Private Sub EvaluateStringExpression(Expression As String) As String
	Expression = Expression.Trim

	If Expression = "" Then
		ExprError = True
		Return ""
	End If

	'Split string expression at + signs outside quotes and brackets.
	Dim Parts As List
	Parts.Initialize

	Dim CurrentPart As StringBuilder
	CurrentPart.Initialize

	Dim InQuotes As Boolean = False
	Dim BracketLevel As Int = 0
	Dim HasConcatenation As Boolean = False

	For i = 0 To Expression.Length - 1
		Dim CurrentChar As String = Expression.SubString2(i, i + 1)

		If CurrentChar = Chr(34) Then
			InQuotes = Not(InQuotes)

		Else If InQuotes = False Then
			If CurrentChar = "(" Then BracketLevel = BracketLevel + 1
			If CurrentChar = ")" Then BracketLevel = BracketLevel - 1

			If CurrentChar = "+" And BracketLevel = 0 Then
				Parts.Add(CurrentPart.ToString.Trim)
				CurrentPart.Initialize
				HasConcatenation = True
				Continue
			End If
		End If

		CurrentPart.Append(CurrentChar)
	Next

	Parts.Add(CurrentPart.ToString.Trim)

	If InQuotes Or BracketLevel <> 0 Then
		ExprError = True
		Return ""
	End If

	'Concatenate string expressions.
	If HasConcatenation Then
		Dim CombinedValue As StringBuilder
		CombinedValue.Initialize

		For Each Part As String In Parts
			If Part = "" Then
				ExprError = True
				Return ""
			End If

			Dim PartValue As String = EvaluateStringExpression(Part)

			If ExprError Then Return ""

			CombinedValue.Append(PartValue)
		Next

		Return CombinedValue.ToString
	End If

	'String literal.
	If Expression.StartsWith(Chr(34)) And _
		Expression.EndsWith(Chr(34)) And Expression.Length >= 2 Then

		Return Expression.SubString2(1, Expression.Length - 1)
	End If

	'String variable.
	If Expression.EndsWith("$") Then
		Dim VariableName As String = Expression.ToUpperCase

		If Variables.ContainsKey(VariableName) Then
			Return Variables.Get(VariableName)
		End If

		ExprError = True
		Return ""
	End If

	Dim FunctionName As String = Expression.ToUpperCase
	Dim FunctionLength As Int

	Select Case True
		Case FunctionName.StartsWith("LEFT$(")
			FunctionLength = 6
		Case FunctionName.StartsWith("RIGHT$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("MID$(")
			FunctionLength = 5
		Case FunctionName.StartsWith("STR$(")
			FunctionLength = 5
		Case FunctionName.StartsWith("CHR$(")
			FunctionLength = 5
		Case FunctionName.StartsWith("SPACE$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("STRING$(")
			FunctionLength = 8
		Case FunctionName.StartsWith("UCASE$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("LCASE$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("LTRIM$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("RTRIM$(")
			FunctionLength = 7
		Case FunctionName.StartsWith("TRIM$(")
			FunctionLength = 6
		Case Else
			ExprError = True
			Return ""
	End Select

	If Expression.EndsWith(")") = False Then
		ExprError = True
		Return ""
	End If

	'Extract function arguments.
	Dim Arguments As String = Expression.SubString2(FunctionLength, Expression.Length - 1)

	Dim ArgumentList As List
	ArgumentList.Initialize

	Dim CurrentArgument As StringBuilder
	CurrentArgument.Initialize

	InQuotes = False
	BracketLevel = 0

	For i = 0 To Arguments.Length - 1
		Dim ArgumentChar As String = Arguments.SubString2(i, i + 1)

		If ArgumentChar = Chr(34) Then
			InQuotes = Not(InQuotes)
		Else If InQuotes = False Then
			If ArgumentChar = "(" Then BracketLevel = BracketLevel + 1
			If ArgumentChar = ")" Then BracketLevel = BracketLevel - 1

			If ArgumentChar = "," And BracketLevel = 0 Then
				ArgumentList.Add(CurrentArgument.ToString.Trim)
				CurrentArgument.Initialize
				Continue
			End If
		End If

		CurrentArgument.Append(ArgumentChar)
	Next

	ArgumentList.Add(CurrentArgument.ToString.Trim)

	If InQuotes Or BracketLevel <> 0 Then
		ExprError = True
		Return ""
	End If

	'Check number of arguments.
	Dim ExpectedArguments As Int = 2

	If FunctionName.StartsWith("MID$(") Then ExpectedArguments = 3
	If FunctionName.StartsWith("STR$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("CHR$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("SPACE$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("UCASE$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("LCASE$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("LTRIM$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("RTRIM$(") Then ExpectedArguments = 1
	If FunctionName.StartsWith("TRIM$(") Then ExpectedArguments = 1

	If ArgumentList.Size <> ExpectedArguments Then
		ExprError = True
		Return ""
	End If

	'STR$: Convert numeric expression to string.
	If FunctionName.StartsWith("STR$(") Then
		Dim NumericResult As Double = EvaluateNumericExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Return NumberFormat(NumericResult, 1, 6)
	End If

	'CHR$: Convert number to character.
	If FunctionName.StartsWith("CHR$(") Then
		Dim CharacterCode As Double = EvaluateNumericExpression(ArgumentList.Get(0))

		If ExprError Or CharacterCode < 0 Or CharacterCode > 255 Then
			ExprError = True
			Return ""
		End If

		Return Chr(Floor(CharacterCode))
	End If

	'SPACE$: Generate spaces.
	If FunctionName.StartsWith("SPACE$(") Then
		Dim SpaceCountValue As Double = EvaluateNumericExpression(ArgumentList.Get(0))

		If ExprError Or SpaceCountValue < 0 Or SpaceCountValue > 10000 Then
			ExprError = True
			Return ""
		End If

		Dim SpaceCount As Int = Floor(SpaceCountValue)
		Dim SpaceBuilder As StringBuilder
		SpaceBuilder.Initialize

		For i = 1 To SpaceCount
			SpaceBuilder.Append(" ")
		Next

		Return SpaceBuilder.ToString
	End If

	'STRING$: Repeat a character.
	If FunctionName.StartsWith("STRING$(") Then
		Dim RepeatCountValue As Double = EvaluateNumericExpression(ArgumentList.Get(0))

		If ExprError Or RepeatCountValue < 0 Or RepeatCountValue > 10000 Then
			ExprError = True
			Return ""
		End If

		Dim RepeatCount As Int = Floor(RepeatCountValue)
		Dim RepeatChar As String = ArgumentList.Get(1)

		'Character supplied as a string literal.
		If RepeatChar.StartsWith(Chr(34)) And _
			RepeatChar.EndsWith(Chr(34)) And RepeatChar.Length >= 2 Then

			RepeatChar = RepeatChar.SubString2(1, RepeatChar.Length - 1)

		Else If RepeatChar.ToUpperCase.EndsWith("$") Then

			'Character supplied as a string variable.
			Dim RepeatVariable As String = RepeatChar.ToUpperCase

			If Variables.ContainsKey(RepeatVariable) = False Then
				ExprError = True
				Return ""
			End If

			RepeatChar = Variables.Get(RepeatVariable)

		Else

			'Character supplied as an ASCII code.
			Dim RepeatCharCode As Double = EvaluateNumericExpression(RepeatChar)

			If ExprError Or RepeatCharCode < 0 Or RepeatCharCode > 255 Then
				ExprError = True
				Return ""
			End If

			RepeatChar = Chr(Floor(RepeatCharCode))
		End If

		If RepeatChar.Length <> 1 Then
			ExprError = True
			Return ""
		End If

		Dim RepeatBuilder As StringBuilder
		RepeatBuilder.Initialize

		For i = 1 To RepeatCount
			RepeatBuilder.Append(RepeatChar)
		Next

		Return RepeatBuilder.ToString
	End If

	'UCASE$: Convert string to uppercase.
	If FunctionName.StartsWith("UCASE$(") Then
		Dim CaseSource As String = EvaluateStringExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Return CaseSource.ToUpperCase
	End If

	'LCASE$: Convert string to lowercase.
	If FunctionName.StartsWith("LCASE$(") Then
		Dim CaseSource As String = EvaluateStringExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Return CaseSource.ToLowerCase
	End If

	'LTRIM$: Remove leading spaces.
	If FunctionName.StartsWith("LTRIM$(") Then
		Dim TrimSource As String = EvaluateStringExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Dim TrimStart As Int = 0

		Do While TrimStart < TrimSource.Length
			If TrimSource.SubString2(TrimStart, TrimStart + 1) <> " " Then Exit
			TrimStart = TrimStart + 1
		Loop

		Return TrimSource.SubString(TrimStart)
	End If

	'RTRIM$: Remove trailing spaces.
	If FunctionName.StartsWith("RTRIM$(") Then
		Dim TrimSource As String = EvaluateStringExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Dim TrimEnd As Int = TrimSource.Length

		Do While TrimEnd > 0
			If TrimSource.SubString2(TrimEnd - 1, TrimEnd) <> " " Then Exit
			TrimEnd = TrimEnd - 1
		Loop

		Return TrimSource.SubString2(0, TrimEnd)
	End If

	'TRIM$: Remove leading and trailing spaces.
	If FunctionName.StartsWith("TRIM$(") Then
		Dim TrimSource As String = EvaluateStringExpression(ArgumentList.Get(0))

		If ExprError Then Return ""

		Return TrimSource.Trim
	End If

	'Evaluate source string.
	Dim StringArgument As String = ArgumentList.Get(0)
	Dim StringValue As String = ""

	If StringArgument.StartsWith(Chr(34)) And _
		StringArgument.EndsWith(Chr(34)) And StringArgument.Length >= 2 Then

		StringValue = StringArgument.SubString2(1, StringArgument.Length - 1)

	Else
		Dim SourceVariable As String = StringArgument.ToUpperCase

		If SourceVariable.EndsWith("$") = False Or Variables.ContainsKey(SourceVariable) = False Then
			ExprError = True
			Return ""
		End If

		StringValue = Variables.Get(SourceVariable)
	End If

	'Evaluate start position for MID$.
	Dim StartPosition As Int = 1

	If FunctionName.StartsWith("MID$(") Then
		Dim StartValue As Double = EvaluateNumericExpression(ArgumentList.Get(1))

		If ExprError Or StartValue < 1 Then
			ExprError = True
			Return ""
		End If

		StartPosition = Floor(StartValue)
	End If

	'Evaluate number of characters.
	Dim LengthIndex As Int = 1
	If FunctionName.StartsWith("MID$(") Then LengthIndex = 2

	Dim RequestedLength As Double = EvaluateNumericExpression(ArgumentList.Get(LengthIndex))

	If ExprError Or RequestedLength < 0 Then
		ExprError = True
		Return ""
	End If

	Dim CharacterCount As Int = Floor(RequestedLength)

	If FunctionName.StartsWith("LEFT$(") Then
		If CharacterCount > StringValue.Length Then CharacterCount = StringValue.Length

		Return StringValue.SubString2(0, CharacterCount)

	Else If FunctionName.StartsWith("RIGHT$(") Then
		If CharacterCount > StringValue.Length Then CharacterCount = StringValue.Length

		Return StringValue.SubString(StringValue.Length - CharacterCount)

	Else
		'MID$: BASIC positions start at 1.
		Dim StartIndex As Int = StartPosition - 1

		If StartIndex >= StringValue.Length Then Return ""

		Dim EndIndex As Int = StartIndex + CharacterCount

		If EndIndex > StringValue.Length Then EndIndex = StringValue.Length

		Return StringValue.SubString2(StartIndex, EndIndex)
	End If
End Sub

Private Sub IsStringExpressionForPrint(Item As String) As Boolean
	Dim FirstPart As String = Item.Trim
	Dim InQuotes As Boolean = False
	Dim BracketLevel As Int = 0

	For i = 0 To FirstPart.Length - 1
		Dim CurrentChar As String = FirstPart.SubString2(i, i + 1)

		If CurrentChar = Chr(34) Then
			InQuotes = Not(InQuotes)

		Else If InQuotes = False Then
			If CurrentChar = "(" Then BracketLevel = BracketLevel + 1
			If CurrentChar = ")" Then BracketLevel = BracketLevel - 1

			If CurrentChar = "+" And BracketLevel = 0 Then
				FirstPart = FirstPart.SubString2(0, i).Trim
				Exit
			End If
		End If
	Next

	If FirstPart.StartsWith(Chr(34)) Then Return True

	Dim UpperPart As String = FirstPart.ToUpperCase

	If UpperPart.EndsWith("$") Then Return True

	If UpperPart.StartsWith("LEFT$(") Or _
	    UpperPart.StartsWith("RIGHT$(") Or _
	    UpperPart.StartsWith("MID$(") Or _
	    UpperPart.StartsWith("STR$(") Or _
	    UpperPart.StartsWith("CHR$(") Or _
	    UpperPart.StartsWith("SPACE$(") Or _
	    UpperPart.StartsWith("STRING$(") Or _
	    UpperPart.StartsWith("UCASE$(") Or _
	    UpperPart.StartsWith("LCASE$(") Or _
		UpperPart.StartsWith("LTRIM$(") Or _
		UpperPart.StartsWith("RTRIM$(") Or _
		UpperPart.StartsWith("TRIM$(") Then

			Return True
	End If

	Return False
End Sub


Private Sub SpaceString(Count As Int) As String
	Dim Result As StringBuilder
	Result.Initialize

	For i = 1 To Count
		Result.Append(" ")
	Next

	Return Result.ToString
End Sub

Private Sub HandleProgramError(Message As String) As Boolean

	If ErrorHandlerRunning Or ErrorHandlerEnabled = False Then
		PrintText(Message)
		RunPosition = RunLines.Size
		Return False
	End If

	ErrorLinePosition = RunPosition - 1
	ErrorNextPosition = RunPosition
	ErrorMessage = Message

	'Extract the BASIC line number.
	ErrorLineNumber = RunLines.Get(ErrorLinePosition)

	'Determine error code.
	If Message.Contains("UNDEFINED LINE") Then
		ErrorCode = 5
	Else If Message.Contains("SYNTAX ERROR") Then
		ErrorCode = 20
	Else If Message.Contains("NEXT WITHOUT FOR") Then
		ErrorCode = 22
	Else If Message.Contains("RETURN WITHOUT GOSUB") Then
		ErrorCode = 23
	Else
		ErrorCode = 20
	End If

	ErrorHandlerRunning = True

	Dim HandlerPosition As Int = FindRunPosition(ErrorHandlerLine)

	If HandlerPosition < 0 Then
		PrintText("?UNDEFINED ERROR HANDLER LINE " & ErrorHandlerLine)
		RunPosition = RunLines.Size
		ErrorHandlerRunning = False
		Return False
	End If

	RunPosition = HandlerPosition

	Return True
End Sub

Private Sub ExecuteOnError(LineCode As String) As Boolean
	Dim UpperLine As String = LineCode.ToUpperCase.Trim

	If UpperLine.StartsWith("ON ERROR GOTO ") = False Then Return False

	Dim TargetText As String = LineCode.SubString(14).Trim

	If IsNumber(TargetText) = False Then Return False

	Dim TargetLine As Int = TargetText

	If TargetLine = 0 Then
		ErrorHandlerEnabled = False
		ErrorHandlerLine = 0
		Return True
	End If

	If FindRunPosition(TargetLine) < 0 Then Return False

	ErrorHandlerLine = TargetLine
	ErrorHandlerEnabled = True

	Return True
End Sub

Private Sub ExecuteResume(LineCode As String) As Boolean

	If ErrorHandlerRunning = False Then
		PrintText("?RESUME WITHOUT ERROR")
		Return False
	End If

	Dim ResumeCommand As String = LineCode.Trim.ToUpperCase

	Select Case ResumeCommand

		Case "RESUME"
			RunPosition = ErrorLinePosition

		Case "RESUME NEXT"
			RunPosition = ErrorNextPosition

		Case Else
			Return False

	End Select

	'The handler has completed its work.
	ErrorHandlerRunning = False
	ErrorMessage = ""

	Return True
End Sub

Private Sub ResetErrorHandler

	ErrorHandlerLine = 0
	ErrorHandlerEnabled = False
	ErrorHandlerRunning = False

	ErrorLinePosition = -1
	ErrorNextPosition = -1
	ErrorMessage = ""

End Sub

Private Sub FindRunPosition(TargetLine As Int) As Int
	For i = 0 To RunLines.Size - 1
		Dim LineNumber As Int = RunLines.Get(i)

		If LineNumber = TargetLine Then Return i
	Next

	Return -1
End Sub
