package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.b4xmainpage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4j.example.b58serial _serial = null;
public anywheresoftware.b4a.objects.collections.List _ports = null;
public anywheresoftware.b4j.objects.ComboBoxWrapper _cmbcomlist = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtsendstring = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtlog = null;
public anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
public b4j.example.b58protocol _b58protocol = null;
public b4j.example.utils _utils = null;
public b4j.example.main _main = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _b4xpage_closerequest() throws Exception{
ResumableSub_B4XPage_CloseRequest rsub = new ResumableSub_B4XPage_CloseRequest(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_B4XPage_CloseRequest extends BA.ResumableSub {
public ResumableSub_B4XPage_CloseRequest(b4j.example.b4xmainpage parent) {
this.parent = parent;
}
b4j.example.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 36;BA.debugLine="ExitApplication";
parent.__c.ExitApplication();
 //BA.debugLineNum = 37;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 31;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 32;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public String  _btnopen_click() throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Private Sub BtnOpen_Click";
 //BA.debugLineNum = 54;BA.debugLine="Serial.ExecuteCommand(\"@SER LISTPORTS\")";
_serial._executecommand("@SER LISTPORTS");
 //BA.debugLineNum = 55;BA.debugLine="Serial.ExecuteCommand(\"@SER CONNECT COM10\")";
_serial._executecommand("@SER CONNECT COM10");
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private Serial As B58Serial";
_serial = new b4j.example.b58serial();
 //BA.debugLineNum = 13;BA.debugLine="Private Ports As List";
_ports = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 15;BA.debugLine="Private CmbComList As ComboBox";
_cmbcomlist = new anywheresoftware.b4j.objects.ComboBoxWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private TxtSendString As B4XView";
_txtsendstring = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private TxtLog As B4XView";
_txtlog = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 25;BA.debugLine="Serial.Initialize(Me, \"Serial\")";
_serial._initialize(ba,this,"Serial");
 //BA.debugLineNum = 26;BA.debugLine="Ports.Initialize";
_ports.Initialize();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _serial_connected() throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Private Sub Serial_Connected";
 //BA.debugLineNum = 41;BA.debugLine="Log($\"[Main.Serial_Connected] OK\"$)";
__c.LogImpl("612910593",("[Main.Serial_Connected] OK"),0);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public String  _serial_datareceived(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Private Sub Serial_DataReceived(buffer() As Byte)";
 //BA.debugLineNum = 45;BA.debugLine="Log($\"[Main.Serial_DataReceived] ${bc.HexFromByte";
__c.LogImpl("612976129",("[Main.Serial_DataReceived] "+__c.SmartStringFormatter("",(Object)(_bc.HexFromBytes(_buffer)))+""),0);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _serial_portsfound(anywheresoftware.b4a.objects.collections.List _p) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Private Sub Serial_PortsFound(p As List)";
 //BA.debugLineNum = 49;BA.debugLine="Log($\"[Main.Serial_PortsFound] ${p}\"$)";
__c.LogImpl("613041665",("[Main.Serial_PortsFound] "+__c.SmartStringFormatter("",(Object)(_p.getObject()))+""),0);
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
